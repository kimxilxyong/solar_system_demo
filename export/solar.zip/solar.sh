#!/bin/sh
printf '\033c\033]0;%s\a' Solar System
base_path="$(dirname "$(realpath "$0")")"
"$base_path/solar" "$@"
